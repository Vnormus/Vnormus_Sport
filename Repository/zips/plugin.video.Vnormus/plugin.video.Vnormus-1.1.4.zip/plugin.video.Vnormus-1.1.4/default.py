# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
links_sport=[('ONE HD','plugin://program.plexus/?mode=1&url=acestream://4600d71f2aca9ee0d3b9a3a85daa7cdcb838cb44&name=ONE HD','http://www.isramedia.net/images/users/2/9ad10ced69d71d618ec6eed88623b412.png'),
       ('SPORT 1HD','plugin://program.plexus/?mode=1&url=acestream://83cbec1ed37cb020c16b15e5a576d2097a68d47f&name=sport 1 HD','https://i.ytimg.com/vi/ER59bQrDnYQ/hqdefault.jpg'),
	   ('SPORT 2HD','plugin://program.plexus/?mode=1&url=acestream://b5838f14ee0f0017d46d48dcf99abeccd619af17&name=sport 2 HD','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOABNo308fzeUDJJO-KchsnQt_4kmaQ5zh-mnyYb-OvMsT9srk'),
	   ('SPORT 5HD','plugin://program.plexus/?mode=1&url=acestream://7c74c562d01cb45b10734d8c946cb2193f310a16&name=sport 1 HD','http://www.isramedia.net/images/users/2/84822b54df911f0da4774966f1efcd81.png'),
	   ('SPORT 5+ LIVE HD','plugin://program.plexus/?mode=1&url=acestream://1bceb8954e88c0ea3eed451ba5bd9d31ebd54ddb&name=SPORT 5+ LIVE HD','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSi_3E8lsItgM1XDBqZ2VjtdInVHKI4Zt30W7d-bT6vF_4UkRc_'),
      
      ]
links_sky=[('SKY SPORT arena HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_1a4609.acelive&.mp4','https://media.info/i/lf/900/1507600420/6753.png'),
       ('SKY SPORT cricket HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_33b5bc.acelive&.mp4','http://video.skysports.com/hyeXJ1YjE6waqh2Ib141MG-nHWqjE5TK/Ut_HKthATH4eww8X4xMDoxOjA4MTsiGN'),
	   ('SKY SPORT golf HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_3482d7.acelive&.mp4','http://img.skysports.com/17/07/768x432/hweXJ1YjE6-ITknsSwJqF4P27S9L0G0N.jpg?20170709111455'),
	   ('SKY SPORT F1 HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_b445b9.acelive&.mp4','https://vignette.wikia.nocookie.net/f1wikia/images/7/77/SkySportsF1.png/revision/latest?cb=20140320200040'),
	   ('SKY SPORT Premier League HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_936eb6.acelive&.mp4','http://e0.365dm.com/16/08/1-1/40/pl-logo-blog-premier-league_3758341.jpg?20160805124844'),
	   ('SKY SPORT main event HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_96ae42.acelive&.mp4','http://web.static.nowtv.com/images/NOWTV_2017/02_TV_Passes/03_Sport/Sky_Sports_Rebrand/Sports_channels_Main_Event.png'),
      
      ]
links_BT=[('BT SPORT 1HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_dfed29.acelive&.mp4','http://i.imgur.com/F2R303x.png'),
       ('BT SPORT 2HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_ba2458.acelive&.mp4','http://static.ontvtonight.co.uk/static/2/Open/SourceLogos/400x300/BTSport2HD.png'),
	   ('BT SPORT 3HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_859ed8.acelive&.mp4','http://sport.bt.com/s/assets/ucl/images/btsport3.png'),
	   ('BT SPORT ESPN HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_535831.acelive&.mp4','http://sport.bt.com/s/assets/ucl/images/btsportespn.png'),
      
      ]
links_israel=[('רשת','http://besttv1.aoslive.it.best-tv.com/reshet/studio/index.m3u8','http://img.bizportal.co.il/giflib/news/rsPhoto/sz_173/rsz_615_346_reshet615_020817.jpg'),
       ('קשת','http://192.99.18.85:1935/live/channel22/chunklist_w1365968436.m3u8','https://upload.wikimedia.org/wikipedia/he/d/df/Keshet12.png'),
	   ('ערוץ 10','http://nana10-hdl-il-sw.ctedgecdn.net/Nana10-Live/amlst:hd_,500,1000,1200,2400,/playlist.m3u8','https://lh3.googleusercontent.com/RwX3kbdB_uWSqZt3g4LimzFTePjAuq-frNrTbiMgpqXsKmqb2vukGEnp4nmbdKPUYhj5=w300'),
	   ('כאן 11','http://82.80.192.28/ipbc_IPBCchannel11LVMRepeat/_definst_/smil:IPBCchannel11LVM.smil/playlist.m3u8','http://www.directorsguild.org.il/upload/infocenter/info_images/06082016214327@taagid.jpg'),
      ]
links_eurosport=[('eurosport 1HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_c36a54.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/1/15/Europsporthd.svg/revision/latest/scale-to-width-down/390?cb=20151013121728'),
       ('eurosport 2HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_1da2c1.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/4/4e/Eurosport_2_HD.png/revision/latest?cb=20170424081628'),
	   ('eurosport news','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_765030.acelive&.mp4','https://vignette1.wikia.nocookie.net/logopedia/images/f/f5/Eurosport_news.png/revision/latest?cb=20120904171521'),
      ]
links_music=[('VH1 classic','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_04ca63.acelive&.mp4','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoklNMD_ceEzDvmqoOFSLQNnT1e4gPsrg6qGTEru_3lPqagrwt'),
       ('MTV live HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_22ff7c.acelive&.mp4','http://teve.ba/img/articles/1916.jpg'),
	   ('MTV dance','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_816f3b.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/0/09/MTV_DANCE_2010.svg/revision/latest/scale-to-width-down/130?cb=20111124002640'),
	   ('MTV base','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_d35c7a.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/a/a9/MTV_Base_France.svg/revision/latest?cb=20100526151932'),
	   ('MTV hits','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_d396c4.acelive&.mp4','https://upload.wikimedia.org/wikipedia/commons/3/35/Logo_MTV_Hits_2017.png'),
	   ('viva music','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_88ee5ab.acelive&.mp4','https://music.anu.edu.au/sites/music.anu.edu.au/files/styles/anu_doublenarrow_440_296/public/events/musica-viva-logo-event.jpg?itok=0A8cm-7w'),
      ]
links_world=[('Premier Sports HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_c45a5c.acelive&.mp4','http://www.britishicehockey.co.uk/wp-content/uploads/2016/04/premier-sports-logo-full-res-master.jpg'),
       ('NBA HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_e670c8.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/1/1a/NBA_PREMIUM_HD_Logo.png/revision/latest?cb=20160216032423'),
	   ('Canal + Sport HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_6bcbaf.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/f/f9/Canal_hd.png/revision/latest?cb=20111122151715'),
	   ('Extreme Sports','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_bfee96.acelive&.mp4','https://vignette4.wikia.nocookie.net/logopedia/images/f/f0/Extreme_Sports_Channel.svg/revision/latest?cb=20100222175808'),
	   ('FightBox HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_9938c5.acelive&.mp4','https://vignette.wikia.nocookie.net/logopedia/images/9/92/Fightbox_Logo.png/revision/latest?cb=20160116195657'),
	   ('Super tennis HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_9257cb.acelive&.mp4','https://upload.wikimedia.org/wikipedia/it/d/db/Supertennis_logo.png'),
	   ('Fotball 1HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/ttv_625_reg.acelive&.mp4','https://bromleygreen.files.wordpress.com/2011/06/color-football-logo-crop.jpg'),
	   ('Fotball 2HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/ttv_611_reg.acelive&.mp4','https://bromleygreen.files.wordpress.com/2011/06/color-football-logo-crop.jpg'),
	   ('Fotball 3HD','http://127.0.0.1:6878/ace/getstream?url=http://91.92.66.82/trash/ttv-list/acelive/ttv_646_reg.acelive&.mp4','https://bromleygreen.files.wordpress.com/2011/06/color-football-logo-crop.jpg'),
	  ]
links_Plexus=[('sport 1 HD','plugin://program.plexus/?mode=1&url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_844b71.acelive&name=sport 1 HD','https://i.ytimg.com/vi/ER59bQrDnYQ/hqdefault.jpg'),
       ('sport 2 HD','plugin://program.plexus/?mode=1&url=acestream://b5838f14ee0f0017d46d48dcf99abeccd619af17&name=sport 2 HD','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOABNo308fzeUDJJO-KchsnQt_4kmaQ5zh-mnyYb-OvMsT9srk'),
	   ('sport 5 HD','plugin://program.plexus/?mode=1&url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_7a6891.acelive&name=sport 5 HD','http://www.isramedia.net/images/users/2/84822b54df911f0da4774966f1efcd81.png'),
	   ('sport 5 live HD','plugin://program.plexus/?mode=1&url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_c41bd5.acelive&name=sport 5 live HD','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSi_3E8lsItgM1XDBqZ2VjtdInVHKI4Zt30W7d-bT6vF_4UkRc_'),
	   ('ONE HD','plugin://program.plexus/?mode=1&url=http://91.92.66.82/trash/ttv-list/acelive/as_cid_fa0adf.acelive&.mp4','http://www.isramedia.net/images/users/2/9ad10ced69d71d618ec6eed88623b412.png'),
      ]


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def main_menu():
    
    addDir3('ספורט ישראל','links_sport',2,'https://pbs.twimg.com/profile_images/316451557/IFA_CMYK_400x400.jpg','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_Udc25CdEMiDuuFYysQg66r2K2kCBzyBkifNvbutYzAyncLpv','ספורט ישראל')
    addDir3('sky sport','links_sky',2,'http://www.wipeoutmusic.com/wp-content/uploads/sky-sports.jpg','https://pbs.twimg.com/profile_images/722784496353964032/AZr3ob_2.jpg','sky sport')
    addDir3('BT sport','links_BT',2,'http://ksassets.timeincuk.net/wp/uploads/sites/54/2013/08/BT-Sport-3.jpg','http://sportplaylists.com/wp-content/uploads/2016/11/photo.jpg','BT sport')
    addDir3('ערוצים ישראל','links_israel',2,'http://images.globes.co.il/images/NewGlobes/big_image_800/2017/trt888.jpg','http://images.globes.co.il/images/NewGlobes/big_image_800/2017/trt888.jpg','ערוצים ישראל')
    addDir3('eurosport','links_eurosport',2,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5ICMVfgpa_Oqki1lN-6ymeTk8Sg8TrkuD0eqTPJoNHENiu1kiKw','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5ICMVfgpa_Oqki1lN-6ymeTk8Sg8TrkuD0eqTPJoNHENiu1kiKw','eurosport')
    addDir3('music','links_music',2,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS49RqyQ8de6ThJdW9XRfhCNCfXgloSEq3vRS5Rwh4AAEhP98Ew','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS49RqyQ8de6ThJdW9XRfhCNCfXgloSEq3vRS5Rwh4AAEhP98Ew','music')
    addDir3('world','links_world',2,'http://z.cdn.turner.com/cnn/.e/interactive/2013/racism.in.football/images/logo_world_sport_220.png','https://danielchammas.files.wordpress.com/2015/05/sports-logo.png','world')
    addDir3('Plexus','links_Plexus',2,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCbHhDyRHWtqKeglBy5oPHQeel8bwVEyq_nmt0IpKeds1ojr9s','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCbHhDyRHWtqKeglBy5oPHQeel8bwVEyq_nmt0IpKeds1ojr9s','Plexus')



def get_links(url):
  if url=='links_sport':
    for name,link,image in links_sport:
      addLink( name, link,3,False,image)
  if url=='links_sky':
    for name,link,image in links_sky:
      addLink( name, link,3,False,image)
  if url=='links_BT':
    for name,link,image in links_BT:
      addLink( name, link,3,False,image)
  if url=='links_israel':
    for name,link,image in links_israel:
      addLink( name, link,3,False,image)
  if url=='links_eurosport':
    for name,link,image in links_eurosport:
      addLink( name, link,3,False,image)
  if url=='links_music':
    for name,link,image in links_music:
      addLink( name, link,3,False,image)
  if url=='links_world':
    for name,link,image in links_world:
      addLink( name, link,3,False,image)
  if url=='links_Plexus':
    for name,link,image in links_Plexus:
      addLink( name, link,3,False,image)
      
def play(url,name):
  logging.warning(url)
  listitem = xbmcgui.ListItem(path=url)
  listitem.setInfo( type="Video", infoLabels={ "Title": name } )
  listitem.setInfo( type="Music", infoLabels={ "Title": name } )
  xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     get_links(url)
elif mode==3:
      play(url,name)
      
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

